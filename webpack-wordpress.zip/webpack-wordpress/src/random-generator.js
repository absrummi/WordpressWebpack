export default class RandomGenerator {
    static randomInteger() {
        return Math.ceil(Math.random() * 100) + " updated";
    }

    static randomRange(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
}